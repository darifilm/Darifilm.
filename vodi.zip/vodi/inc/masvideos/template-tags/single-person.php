<?php
/**
 * Single Person Template Functions
 */

if ( ! function_exists( 'vodi_template_single_person_personal_info_wrap_open' ) ) {
    function vodi_template_single_person_personal_info_wrap_open() {
        ?><div class="single-person__personal-info"><?php
    }
}

if ( ! function_exists( 'vodi_template_single_person_personal_info_wrap_close' ) ) {
    function vodi_template_single_person_personal_info_wrap_close() {
        ?></div><?php
    }
}