<?php
/**
 * The template for displaying the footer blank.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package vodi
 */

?>
            </div><!-- /.site-content-inner -->

        <?php do_action( 'vodi_content_bottom' ); ?>
        
    </div><!-- #content -->

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>